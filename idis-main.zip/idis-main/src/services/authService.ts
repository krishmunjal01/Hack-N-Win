export type UserRole =
  | "national_admin"
  | "state_officer"
  | "district_officer"
  | "building_authority"
  | "emergency_response";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  state?: string;
  district?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData extends LoginCredentials {
  name: string;
  role: UserRole;
  state?: string;
  district?: string;
}

// Hardcoded demo credentials
const DEMO_CREDENTIALS: { email: string; password: string; user: AuthUser }[] = [
  {
    email: "national@idis.gov",
    password: "Admin@123",
    user: { id: "admin_001", name: "National Administrator", email: "national@idis.gov", role: "national_admin" },
  },
  {
    email: "state@idis.gov",
    password: "State@123",
    user: { id: "state_001", name: "State Administrator", email: "state@idis.gov", role: "state_officer", state: "MH" },
  },
  {
    email: "district@idis.gov",
    password: "District@123",
    user: { id: "district_001", name: "District Administrator", email: "district@idis.gov", role: "district_officer", state: "MH", district: "MH-MUM" },
  },
  {
    email: "officer@idis.gov",
    password: "Officer@123",
    user: { id: "officer_001", name: "Field Officer", email: "officer@idis.gov", role: "building_authority" },
  },
];

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export async function login(credentials: LoginCredentials): Promise<{ user: AuthUser; otp: string } | null> {
  const match = DEMO_CREDENTIALS.find(
    (c) => c.email === credentials.email && c.password === credentials.password
  );
  if (!match) return null;
  const otp = generateOTP();
  // TODO: Replace with EmailJS / WhatsApp OTP delivery
  console.log(`[IDIS OTP] Generated OTP for ${match.email}: ${otp}`);
  return { user: match.user, otp };
}

export async function adminLogin(credentials: LoginCredentials): Promise<{ user: AuthUser; otp: string } | null> {
  return login(credentials);
}

export async function register(data: RegisterData): Promise<AuthUser> {
  return {
    id: "new_officer_001",
    name: data.name,
    email: data.email,
    role: data.role,
  };
}

export async function forgotPassword(email: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function verifyOTP(email: string, otp: string): Promise<{ success: boolean }> {
  return { success: true };
}

export async function logout(): Promise<void> {
  // TODO: Clear session
}

export function getRoleLabel(role: UserRole): string {
  const labels: Record<UserRole, string> = {
    national_admin: "National Administrator",
    state_officer: "State Administrator",
    district_officer: "District Administrator",
    building_authority: "Building Authority Officer",
    emergency_response: "Emergency Response Officer",
  };
  return labels[role];
}

export function getRoleAccent(role: UserRole): string {
  switch (role) {
    case "national_admin": return "role-national";
    case "state_officer": return "role-state";
    case "district_officer": return "role-district";
    default: return "role-officer";
  }
}
